﻿

import sys
import logging
import clr
clr.AddReference('System.Windows.Forms')
clr.AddReference('System.Drawing')
from System.Windows.Forms import Application

if 'oDesktop' in globals():
	tempPath = oDesktop.GetTempDirectory()
	sysPath = oDesktop.GetSysLibDirectory()
else:
	oDesktop = None
	tempPath = 'C:/Program Files/AnsysEM/temp/'
	sysPath = 'C:/Program Files/AnsysEM/Q3DExtractor12.0/Win64/syslib'
	
sys.path.append(sysPath + "/Toolkits/Lib/TLine")


import MainForm
import anstDebug



#oLog = anstDebug.anstDebug('TLine', logging.DEBUG, oDesktop)
oLog = anstDebug.anstDebug('TLine', logging.INFO, oDesktop)

logger = oLog.getLogger()
#logger.debug('TempDir: ' + tempPath)
#logger.debug('SysPath: ' + sysPath)

try:
	Application.EnableVisualStyles()
	form = MainForm.MainForm(oDesktop, sysPath)
	#form.SetSysPath(sysPath)
	form.SetDefaults()
	Application.Run(form)
except(e):
	pass


oLog.Finish()