
def GetAllCircuitDesignProbeNames(oDesign):
    names = set()
    if not oDesign:
        return names
    oEditor = oDesign.GetEditor("SchematicEditor")
    if not oEditor:
        return names
    
    # Add all PagePorts
    allPorts = oEditor.GetAllPorts()
    for pp in allPorts:
        ppParts = pp.split('@')
        if len(ppParts) != 2 or ppParts[0] != "PagePort":
            continue
        nmParts = ppParts[1].split(';')
        if len(nmParts) != 2:
            continue
        names.add(nmParts[0])

    # Add all nets
    for nn in oEditor.GetAllNets():
        for ss in oEditor.GetSignals(nn):
            names.add(ss)
        
    return list(names)

#---------------------------------------------------------

def GetTransientCompatibleCircuitSetups(oDesign):
    names = []
    if not oDesign:
        return names
    oSetup = oDesign.GetModule("SimSetup")
    if not oSetup:
        return names
    
    allSetups = oSetup.GetAllSolutionSetups()
    # TODO: Filter to only Transient and Quickeye...
    return allSetups
