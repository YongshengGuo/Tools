import clr
clr.AddReference('System.Xml')
from System import Xml, String

import __main__

#---------------------------------------------------------

class UserDefinedSolution:

	SolutionName = None
	PluginFileLocation = None
	PluginRelativePathName = None
	Properties = {}
	Probes = {}

	kUnassigned = 'UNASSIGNED'

	#---------------------------------------------------------

	def __init__(self):
		pass

	#---------------------------------------------------------

	def ReadXML(self, fname):
		#AddInfoMessage('{0}'.format(fname))
		doc = Xml.XmlDocument()
		try:
			doc.Load(fname)
		except:
			return False
		
		udsNdList = doc.GetElementsByTagName('UserDefinedSolution')
		if udsNdList.Count == 0:
			return False
		
		# For now, only process the first UserDefinedSolution... this can easily be extended later to create several
		udsNd = udsNdList[0]

		slnName = udsNd.Attributes['SolutionName'].Value if udsNd.Attributes['SolutionName'] is not None else ''
		pluginLoc = udsNd.Attributes['PluginFileLocation'].Value if udsNd.Attributes['PluginFileLocation'] is not None else ''
		pluginRel = udsNd.Attributes['PluginFileRelativePathName'].Value if udsNd.Attributes['PluginFileRelativePathName'] is not None else ''
		if slnName.Length==0 or pluginLoc.Length==0 or pluginRel.Length==0:
			return False # all are required...

		self.SolutionName = slnName
		self.PluginFileLocation = pluginLoc
		self.PluginRelativePathName = pluginRel		

		propsNdList = udsNd.GetElementsByTagName('Property')
		self.Properties = {}
		for nd in propsNdList:
			nmAttrib = nd.Attributes['Name']
			valAttrib = nd.Attributes['Value']
			if nmAttrib is not None and valAttrib is not None:
				self.Properties[nmAttrib.Value] = valAttrib.Value

		probesNdList = udsNd.GetElementsByTagName('Probe')
		self.Probes = {}
		for nd in probesNdList:
			nmAttrib = nd.Attributes['Input']
			valAttrib = nd.Attributes['Assignment']
			if nmAttrib is not None and valAttrib is not None:
				self.Probes[nmAttrib.Value] = valAttrib.Value

		return True

	#---------------------------------------------------------

	def WriteXML(self, fname):
		doc = Xml.XmlDocument()
		# Setup the basic tree structure
		doc.LoadXml('<UserDefinedSolution> <PropertyValues/> <ProbeSelection/> </UserDefinedSolution>')

		root = doc.DocumentElement
		xmldecl = doc.CreateXmlDeclaration('1.0', 'utf-8', None)
		doc.InsertBefore(xmldecl, root)

		udsNd = doc.GetElementsByTagName('UserDefinedSolution')[0]
		# Create the UDS attribs		
		attr = udsNd.SetAttributeNode('SolutionName', '')
		attr.Value = self.SolutionName if not String.IsNullOrEmpty(self.SolutionName) else ''
		attr = udsNd.SetAttributeNode('PluginFileLocation', '')
		attr.Value = self.PluginFileLocation if not String.IsNullOrEmpty(self.PluginFileLocation) else ''
		attr = udsNd.SetAttributeNode('PluginFileRelativePathName', '')
		attr.Value = self.PluginRelativePathName if not String.IsNullOrEmpty(self.PluginRelativePathName) else ''

		propValuesNd = doc.GetElementsByTagName('PropertyValues')[0]
		for k, v in self.Properties.iteritems():
			nd = doc.CreateElement('Property')
			attr = nd.SetAttributeNode('Name', '')
			attr.Value = k
			attr = nd.SetAttributeNode('Value', '')
			attr.Value = v
			propValuesNd.AppendChild(nd)


		probeSelectionNd = doc.GetElementsByTagName('ProbeSelection')[0]
		for k, v in self.Probes.iteritems():
			nd = doc.CreateElement('Probe')
			attr = nd.SetAttributeNode('Input', '')
			attr.Value = k
			attr = nd.SetAttributeNode('Assignment', '')
			attr.Value = v
			probeSelectionNd.AppendChild(nd)

		try:
			doc.Save(fname)
		except:
			return False

		return True

	#---------------------------------------------------------

	def CreateUserDefinedSolution(self, oDesign, setup):
		if not oDesign:
			return ''
		oUDS = oDesign.GetModule('UserDefinedSolutionModule')
		if not oUDS:
			return ''
		
		simvaluecontext = [1,0,2,0,False,False,-1,1,0,1,1,"",0,0]
		
		udsPropList = []
		#__main__.AddInfoMessage('{0}'.format(self.Properties))
		for k, v in self.Properties.iteritems():
			udsPropList.append('{0}:='.format(k))
			udsPropList.append(v)
	
		udsProbeList = []
		for k, v in self.Probes.iteritems():
			#__main__.AddInfoMessage('{0} = {1}'.format(k, v))
			thisVal = v
			if len(v) == 0:
				self.CreateUnassignedOutputVariable(oDesign, setup)
				thisVal = self.kUnassigned

			thisProbe = ["Standard"]
			thisProbe.append(k)
			thisProbe.append(setup)
			thisProbe.append( ["NAME:Context", "SimValueContext:=", simvaluecontext] )
			thisProbe.append( [ "Time:=", ["All"] ] )
			thisProbe.append( ["Probe Component:=", ["{0}".format(thisVal)]] )
			thisProbe.append( [] )
			udsProbeList.append(thisProbe)

		#__main__.AddInfoMessage("{0}".format(self.SolutionName))
		#__main__.AddInfoMessage("{0}".format(self.PluginFileLocation))
		#__main__.AddInfoMessage("{0}".format(self.PluginRelativePathName))
		#__main__.AddInfoMessage("{0}".format(udsPropList))
		#__main__.AddInfoMessage("{0}".format(udsProbeList))

		udsresultNm = oUDS.CreateUserDefinedSolution(self.SolutionName, self.PluginFileLocation, self.PluginRelativePathName, udsPropList, udsProbeList, [])
				
		return udsresultNm


	#---------------------------------------------------------
	
	def CreateUnassignedOutputVariable(self, oDesign, setup):
		if oDesign.GetOutputVariables().IndexOf(self.kUnassigned) != -1:
			return

		oOutVar = oDesign.GetModule('OutputVariable')
		simvaluecontext = [1,0,2,0,False,False,-1,1,0,1,1,"",0,0]
		oOutVar.CreateOutputVariable(self.kUnassigned, '9999', setup, 'Standard', ["NAME:Context", "SimValueContext:=", simvaluecontext])
